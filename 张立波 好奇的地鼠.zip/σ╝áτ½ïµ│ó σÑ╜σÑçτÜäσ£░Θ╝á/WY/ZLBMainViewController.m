//
//  newsViewController.m
//  WY
//
//  Created by tarena on 15/11/20.
//  Copyright (c) 2015年 tarena. All rights reserved.
//

#import "ZLBMainViewController.h"
#import "ZLBNewsTableViewController.h"
#import "ZLBEditLabel.h"
#define NUMBEROFEDIT (self.newsURLs.count)
#define EDITWIDTH (self.view.frame.size.width * 0.19)
#define EDITHEIGHT (self.view.frame.size.height * 0.06 )
#define BIGHEIGHT (self.view.frame.size.height - 64 - 64 - EDITHEIGHT)
#define WIDTH  (self.view.bounds.size.width)
#define HEIGHT (self.view.bounds.size.height)
@interface ZLBMainViewController ()<UIScrollViewDelegate,UITableViewDelegate>
/** 标题栏 */
@property(nonatomic,strong)UIScrollView *editScroll;
/** 内容栏*/
@property(nonatomic,strong)UIScrollView *bigScroll;
/**  新闻的接口数据 */
@property(nonatomic,strong)NSArray *newsURLs;
/**天气是否显示*/
@property(nonatomic,assign,getter=isWeatherShow)BOOL weatherShow;
//天气按钮
@property (nonatomic, strong) UIButton *weatherBtn;
//显示天气的 vc
@property (nonatomic, strong) UIButton *button;
@end

@implementation ZLBMainViewController

//懒加载

- (NSArray *)newsURLs{
    if(_newsURLs == nil){
        NSURL *url = [[NSBundle mainBundle] URLForResource:@"NewsURLs" withExtension:@"plist"];
        _newsURLs = [NSArray arrayWithContentsOfURL:url];
        
    }
    return _newsURLs;
}
-(id)initWithCoder:(NSCoder *)aDecoder{
    if(self = [super initWithCoder:aDecoder]){
        self.tabBarItem.title = @"新闻";
        self.navigationItem.title = @"新闻";
        self.navigationController.tabBarItem.selectedImage = [UIImage imageNamed: @"tabbar_icon_news_highlight"];
        [self newsURLs];
    }
    return self;
}
-(void)viewWillAppear:(BOOL)animated{
      self.navigationController.navigationBarHidden = NO;
      self.tabBarController.tabBar.hidden = NO;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self setUpEditScroll];
    [self setUpBigScroll];
    [self addControl];
    [self addLabel];
  
    //解决 Navigation 和 scrollView 在一起会产生偏移的问题
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    //去到导航引起的偏移量 会造成一个问题
    //self.edgesForExtendedLayout = UIRectEdgeNone;
    //解决问题
//    UIWindow *win = [UIApplication sharedApplication].keyWindow;
//    win.backgroundColor = [UIColor whiteColor];
    UITableViewController *news = self.childViewControllers[0];
    [self.bigScroll addSubview:news.view];
    self.editScroll.delegate = self;
    self.bigScroll.delegate = self;
    

}

#pragma mark 设置小滚动器 //体育 头条 娱乐
-(void)setUpEditScroll{
    UIScrollView *edit = [[UIScrollView alloc] init];
    self.editScroll = edit;
    //设置 editScroll 的属性
    edit.frame = CGRectMake(0, 64, self.view.bounds.size.width, EDITHEIGHT);
    edit.contentSize = CGSizeMake(EDITWIDTH * NUMBEROFEDIT, EDITHEIGHT);
    edit.bounces = NO;
    edit.showsHorizontalScrollIndicator = NO;
    edit.pagingEnabled = NO;
    [self.view addSubview:edit];
    edit.tag = 1;
}
#pragma mark 设置大视图
//大得滚动视图
-(void)setUpBigScroll{
    UIScrollView *bigScroll = [[UIScrollView alloc] init];
    self.bigScroll = bigScroll;
    bigScroll.frame = CGRectMake(0, EDITHEIGHT + 64 , self.view.bounds.size.width, BIGHEIGHT);
    //bigScroll.backgroundColor = [UIColor redColor];
    bigScroll.contentSize = CGSizeMake(WIDTH * NUMBEROFEDIT, BIGHEIGHT);
    bigScroll.pagingEnabled = YES;
    bigScroll.showsHorizontalScrollIndicator = NO;
    bigScroll.bounces = NO;
    //设置偏移，其实我不知道为什么发生偏移 可能是表头的关系把 但结果可以了
    //bigScroll.contentInset = UIEdgeInsetsMake(-32, 0, 0, 0);
   [self.view addSubview:bigScroll];
    bigScroll.tag = 2;
}
//添加control
-(void)addControl{
    for (NSInteger i = 0; i < NUMBEROFEDIT; i++){
        //这里要区分 第一个视图 和其他的视图 ,因为所以视图用addChildViewController添加, 第一个直接就存在父类了
        if(i == 0){
            ZLBNewsTableViewController *newsTVC = [[UIStoryboard storyboardWithName:@"News" bundle:[NSBundle mainBundle]] instantiateInitialViewController];
            newsTVC.title = self.newsURLs[i][@"title"];
            newsTVC.urlString = self.newsURLs[i][@"urlString"];
            newsTVC.tableView.frame = self.bigScroll.bounds;
            [self addChildViewController:newsTVC];
        }else{
            ZLBNewsTableViewController *newsTVC = [[UIStoryboard storyboardWithName:@"News" bundle:[NSBundle mainBundle]] instantiateInitialViewController];
            newsTVC.title = self.newsURLs[i][@"title"];
            newsTVC.urlString = self.newsURLs[i][@"urlString"];
            [self addChildViewController:newsTVC];
        }
   
    }
}
//添加label 到editscroll
-(void)addLabel{
    CGFloat lblx = EDITWIDTH;
    CGFloat lbly = 0;
    CGFloat lblh = EDITHEIGHT;
    CGFloat lblw = EDITWIDTH;
    for(NSInteger i = 0;i < NUMBEROFEDIT;i++ ){
        //自定义label
        ZLBEditLabel *lbl = [[ZLBEditLabel alloc] initWithFrame:CGRectMake(lblx * i, lbly, lblw, lblh)];
        //获得子控制器,然后得到它的 title
        UIViewController *vc = self.childViewControllers[i];
        lbl.text = vc.title;
        [self.editScroll addSubview:lbl];
        //设置 tag 值
        lbl.tag = i;
        //用户交互
        lbl.userInteractionEnabled = YES;
        //添加手势
        [lbl addGestureRecognizer:[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(lblClick:)]];
        //设置初始化字体的scale
        if(i == 0){
            lbl.scale = 1;
        }
    }
}
//点击小的滚动视图上的 label
-(void)lblClick:(UITapGestureRecognizer *)ges{
    ZLBEditLabel *lbl = (ZLBEditLabel*)ges.view;
    //获得 index
    NSInteger index = lbl.tag;
    CGFloat offsetX = index * self.bigScroll.frame.size.width;
    CGFloat offsetY = self.bigScroll.contentOffset.y;
    CGPoint offset = CGPointMake(offsetX, offsetY);
    //然后使大的滚动视图 偏移
    [self.bigScroll setContentOffset:offset animated:YES];
}



#pragma mark - UIScrollDelegate
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
}
//滚动视图偏移后做的操作
-(void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView{
    //小的 edit滚动视图偏移后
    if(scrollView.tag == 2){
        NSUInteger index = scrollView.contentOffset.x /self.bigScroll.frame.size.width;
        //滚动标题栏  以下操作使选中的那个 label 在最中间
        ZLBEditLabel *titleLabel = (ZLBEditLabel *)self.editScroll.subviews[index];
        CGFloat offsetx = titleLabel.center.x - WIDTH * 0.5;
        CGFloat offsetMax = self.editScroll.contentSize.width - WIDTH;
       // NSLog(@"%lf",self.editScroll.contentSize.width);;
        if(offsetx < 0){
            offsetx = 0;
        }
        else if(offsetx > offsetMax){
            offsetx = offsetMax;
        }
        CGPoint offset = CGPointMake(offsetx, self.editScroll.contentOffset.y);
        [self.editScroll setContentOffset:offset animated:YES];
        
        for (NSInteger i = 0; i < NUMBEROFEDIT; i++){
            ZLBEditLabel *lbl = (ZLBEditLabel *) self.editScroll.subviews[i];
            lbl.scale = 0;
            if (i == index){
                lbl.scale = 1;
            }
        }
        //获得 label 对应的那个控制器
        ZLBNewsTableViewController *newsVc = self.childViewControllers[index];
        newsVc.index = index;
        //如果它有父类了(已经添加了),就 return
        if (newsVc.view.superview) return;
        //否则就添加到 bigscroll 上
        CGRect frame = CGRectZero;
        //设置控制器的 frame
        frame.origin = CGPointMake(scrollView.contentOffset.x, 0);
        frame.size = scrollView.bounds.size;
        newsVc.view.frame = frame;
        [self.bigScroll addSubview:newsVc.view];
    }
}
/** 滚动结束（手势导致） */
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    [self scrollViewDidEndScrollingAnimation:scrollView];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}



@end
