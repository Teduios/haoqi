//
//  ImagesViewController.m
//  WY
//
//  Created by tarena on 15/12/7.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "ZLBImagesViewController.h"
#import "ZLBNetWorkTools.h"
#import "ZLBNewsImage.h"
#import "ZLBNewsImageDetail.h"
#import "UIImageView+WebCache.h"
@interface ZLBImagesViewController () <UIScrollViewDelegate>


@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@property (weak, nonatomic) IBOutlet UIButton *backButton;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *subTitleLabel;
@property (nonatomic ,strong)NSMutableArray *photos;
@property(nonatomic,strong)NSMutableArray *notes;
@property(nonatomic,strong)NSString *desc;

@end

@implementation ZLBImagesViewController
- (NSMutableArray *)notes {
    if(_notes == nil) {
        _notes = [[NSMutableArray alloc] init];
    }
    return _notes;
}


- (NSMutableArray *)photos {
    if(_photos == nil) {
        _photos = [[NSMutableArray alloc] init];
    }
    return _photos;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.automaticallyAdjustsScrollViewInsets = NO;
//    隐藏导航栏
    self.navigationController.navigationBarHidden = YES;
    self.tabBarController.tabBar.hidden = YES;
    //self.scroll.hidden = NO;

    [self.backButton addTarget:self action:@selector(backClick:) forControlEvents:UIControlEventTouchUpInside];
    
    
//    配置 scroll
    self.scrollView.pagingEnabled = YES;
    self.scrollView.showsHorizontalScrollIndicator = NO;
    self.scrollView.delegate = self;

//    取出关键字
    NSString *one = self.news.photosetID;
    NSString *two = [one substringFromIndex:4];
    NSArray *three = [two componentsSeparatedByString:@"|"];
    NSString *url = [NSString stringWithFormat:@"http://c.m.163.com/photo/api/set/%@/%@.json",[three firstObject],[three lastObject]];
    [self sendRequestWithUrl:url];
    
    
}
-(void)sendRequestWithUrl:(NSString *)url{

    [[ZLBNetWorkTools defaultNetWorkTools]GET:url parameters:nil success:^(NSURLSessionDataTask *task, id responseObject) {
                ZLBNewsImage *image = [ZLBNewsImage parseJsonByDic:responseObject];
                self.desc = image.desc;
        //        给 photo 添加图片的 url(NSString)
                for (ZLBNewsImageDetail *detail in image.photos) {
                    [self.photos addObject:detail.imgurl];
                    [self.notes addObject:detail.note];
                }
                [self setScroll];
                self.titleLabel.text = self.desc== nil?self.desc:@"";
            self.subTitleLabel.text = self.notes[0];
        
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        
    }];
    
}
-(void)setScroll
{
    NSArray *photos = self.photos;
    UIView *lastView = nil;
    //    设置照片
    for (int i = 0; i < photos.count; i ++)
    {
        
        UIImageView *iv = [UIImageView new];
        //iv.contentMode = UIViewContentModeScaleAspectFit;
        [iv sd_setImageWithURL:[NSURL URLWithString:photos[i]] placeholderImage:[UIImage imageNamed:@"placeholder"]];
        [self.scrollView addSubview:iv];
        [iv mas_makeConstraints:^(MASConstraintMaker *make) {
            if(i == 0)
            {
                make.left.mas_equalTo(0);
                make.top.mas_equalTo(0);
                make.bottom.mas_equalTo(0);
               make.size.mas_equalTo(self.scrollView);
            }
            else
            {
                make.left.mas_equalTo(lastView.mas_right).mas_equalTo(0);
                make.top.mas_equalTo(0);
                make.bottom.mas_equalTo(0);
                if(i == photos.count - 1)
                {
                    make.right.mas_equalTo(0);
                }
                make.size.mas_equalTo(lastView);
            }
        }];
        lastView = iv;
    }
    
}
//点击返回按钮
-(void)backClick:(UIButton*)btn
{

    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}


#pragma mark - UIScrollViewDelegate
//方法导致偏移接胡搜
//-(void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView
//{
//    NSInteger X = scrollView.contentOffset.x / self.view.bounds.size.width;
//    self.subTitleLabel.text = self.notes[X];
//}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    
}
//手动导致偏移结束
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    NSInteger X = scrollView.contentOffset.x / self.view.bounds.size.width;
    self.subTitleLabel.text = self.notes[X];
}





@end
