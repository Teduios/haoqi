//
//  NewsContentViewController.m
//  WY
//
//  Created by tarena on 15/12/4.
//  Copyright © 2015年 tarena. All rights reserved.
//
/**
控制器 很多view 公用
 */

#import "ZLBNewsContentViewController.h"
#import "ZLBNewsContentModel.h"
#import "ZLBNewsImageModel.h"
@interface ZLBNewsContentViewController () <UIWebViewDelegate>


/**
 *  这里要拼接 html界面....
 */
@property (weak, nonatomic) IBOutlet UIWebView *webView;
@property (nonatomic ,strong) ZLBNewsContentModel *newsContent;

@end

@implementation ZLBNewsContentViewController
// http://c.m.163.com/nc/article/AHHQIG5B00014JB6/full.html

/**
 *  首次加载
 */
- (void)viewDidLoad {
    [super viewDidLoad];
    self.webView.delegate = self;
    //评论功能 没实现
    //self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"评论" style:UIBarButtonItemStyleDone target:self action:@selector(comment:)];
    NSString *url = [NSString stringWithFormat:@"http://c.m.163.com/nc/article/%@/full.html",self.news.docid];
    
    [[ZLBNetWorkTools manager]GET:url parameters:nil success:^(NSURLSessionDataTask *task, id responseObject) {
        self.newsContent = [ZLBNewsContentModel pareseJsonByDic:responseObject[self.news.docid]];
        [self showWebView];
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        NSLog(@"error%@",error);
    }];
       self.automaticallyAdjustsScrollViewInsets = NO;
//    
//    NSLog(@"dddddd%@",self.news.title);
//    NSString *str = @"http://3g.163.com/news/15/1209/10/BACSJT4M00014PRF.html";
//    NSURL *url = [NSURL URLWithString:str];
//    NSURLRequest *request = [NSURLRequest requestWithURL:url];
//    [self.webView loadRequest:request];
    
}

-(void)viewWillAppear:(BOOL)animated{
    //这样设置没有用
   // self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    self.tabBarController.tabBar.hidden = YES;
}
-(void)showWebView{
    
    NSMutableString *html = [NSMutableString string];
    [html appendString:@"<html>"];
    [html appendString:@"<head>"];
    [html appendFormat:@"<link rel=\"stylesheet\" href=\"%@\">",[[NSBundle mainBundle] URLForResource:@"SXDetails.css" withExtension:nil]];
    [html appendString:@"</head>"];
    
    [html appendString:@"<body>"];
    [html appendString:[self touchBody]];
    [html appendString:@"</body>"];
    
    [html appendString:@"</html>"];
    
    //NSLog(@"html%@",html);
    [self.webView loadHTMLString:html baseURL:nil];

}
- (NSString *)touchBody
{
    NSMutableString *body = [NSMutableString string];
    [body appendFormat:@"<div class=\"title\">%@</div>",self.newsContent.title];
    [body appendFormat:@"<div class=\"time\">%@</div>",self.newsContent.ptime];
    if (self.newsContent.body != nil) {
        [body appendString:self.newsContent.body];
    }
    // 遍历img
    for (ZLBNewsImageModel *detailImgModel in self.newsContent.img) {
        NSMutableString *imgHtml = [NSMutableString string];
        
        // 设置img的div
        [imgHtml appendString:@"<div class=\"img-parent\">"];
        
        // 数组存放被切割的像素
        NSArray *pixel = [detailImgModel.pixel componentsSeparatedByString:@"*"];
        CGFloat width = [[pixel firstObject]floatValue];
        CGFloat height = [[pixel lastObject]floatValue];
        // 判断是否超过最大宽度
        CGFloat maxWidth = [UIScreen mainScreen].bounds.size.width * 0.96;
        if (width > maxWidth) {
            height = maxWidth / width * height;
            width = maxWidth;
        }
        NSString *onload = @"this.onclick = function() {"
        "  window.location.href = 'sx:src=' +this.src;"
        "};";
        [imgHtml appendFormat:@"<img onload=\"%@\" width=\"%f\" height=\"%f\" src=\"%@\">",onload,width,height,detailImgModel.src];
        // 结束标记
        [imgHtml appendString:@"</div>"];
        // 替换标记
        [body replaceOccurrencesOfString:detailImgModel.ref withString:imgHtml options:NSCaseInsensitiveSearch range:NSMakeRange(0, body.length)];
    }
    return body;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}





@end
