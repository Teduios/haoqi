//
//  NewsImageDetail.h
//  WY
//
//  Created by tarena on 15/12/13.
//  Copyright © 2015年 tarena. All rights reserved.
//
/*
 "timgurl": "http://img3.cache.netease.com/photo/0096/2015-12-13/t_BANPMMVT54GI0096.jpg",
 "photohtml": "http://help.3g.163.com/photoview/54GI0096/84446.html#p=BANPMMVT54GI0096",
 "newsurl": "#",
 "squareimgurl": "http://img3.cache.netease.com/photo/0096/2015-12-13/400x400_BANPMMVT54GI0096.jpg",
 "cimgurl": "http://img3.cache.netease.com/photo/0096/2015-12-13/c_BANPMMVT54GI0096.jpg",
 "imgtitle": "",
 "simgurl": "http://img3.cache.netease.com/photo/0096/2015-12-13/s_BANPMMVT54GI0096.jpg",
 "note": "2015年12月9日消息，广州。见过燕子在梁间筑巢，没见过猴子在后院定居。这事可让家住广州市天河区柯木塱金铺北街的街坊犯愁了。两个多月前，一位“不请自来”的客人———一只野猴子进驻涂先生家后院。如今，这只猴子不单在家里讨食，还占山为王，成了涂先生鸡圈里的霸主。两个多月前的一天，住在天河区柯木塱金铺北街某民宅的陈大妈，早上7点左右听到一阵窸窸窣窣的声音，“往屋外一看，一只猴子蹲在树上。”回忆第一次见到后院的小猴子时，陈大妈记忆犹新。陈大妈亲切地称它为“猴猴”。（来源：新华网）",
 "photoid": "BANPMMVT54GI0096",
 "imgurl": "http://img3.cache.netease.com/photo/0096/2015-12-13/BANPMMVT54GI0096.jpg"
 },
 */
#import <Foundation/Foundation.h>

@interface ZLBNewsImageDetail : NSObject
@property (nonatomic ,strong) NSString *note;
@property (nonatomic, strong) NSString *imgurl;

+(instancetype)parseJsonByDic:(NSDictionary *)dic;



@end
