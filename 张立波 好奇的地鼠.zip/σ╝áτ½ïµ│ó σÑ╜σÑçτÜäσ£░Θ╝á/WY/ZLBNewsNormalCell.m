//
//  newsNormalCell.m
//  WY
//
//  Created by tarena on 15/11/29.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "ZLBNewsNormalCell.h"
#import "UIImageView+WebCache.h"
@interface ZLBNewsNormalCell ()

@property (weak, nonatomic) IBOutlet UILabel *titleLabe;
@property (weak, nonatomic) IBOutlet UILabel *subTitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *commentLabel;
@property (weak, nonatomic) IBOutlet UIImageView *IV;
@end

@implementation ZLBNewsNormalCell

-(void)setNewsNormal:(NewsNromal *)newsNormal{
    //一给 newsNormal赋值就 给 cell 里的属性赋值
    _newsNormal = newsNormal;
    
//        NSURL *url = [NSURL URLWithString:newsNormal.imageSrc];
//        NSData *data = [NSData dataWithContentsOfURL:url ];
    [self.IV sd_setImageWithURL:[NSURL URLWithString:newsNormal.imageSrc] placeholderImage:[UIImage imageNamed:@"placeholder"]];
    self.titleLabe.text = newsNormal.title;
    self.subTitleLabel.text = newsNormal.subtile;
    self.commentLabel.text = [NSString stringWithFormat:@"%@",newsNormal.replyCount];
}
- (void)awakeFromNib {
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
