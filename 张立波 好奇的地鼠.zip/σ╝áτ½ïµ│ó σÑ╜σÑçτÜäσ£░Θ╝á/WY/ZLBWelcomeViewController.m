//
//  WelcomeViewController.m
//  WY
//
//  Created by tarena on 15/11/19.
//  Copyright (c) 2015年 tarena. All rights reserved.
//

#define NUMBEROFPHOTO 4
#define SCREENWIDTH (self.view.frame.size.width)
#define ZERO 0
#import "ZLBWelcomeViewController.h"


@interface ZLBWelcomeViewController () <UIScrollViewDelegate>
/**
 *  scroll
 */
@property(nonatomic,strong)UIScrollView *scroll;
/**
 *  传过来的照片
 */
@property (nonatomic, strong)NSArray *photos;
//@property(nonatomic,strong)NSArray *photos;
@end

@implementation ZLBWelcomeViewController
/**
 *  低耦合 懒加载 scroll  自己的事情自己做
 *
 *  @return scroll
 */
-(UIScrollView *)scroll
{
    if(!_scroll)
    {
        _scroll = [UIScrollView new];
//        _scroll.pagingEnabled = YES;
//        _scroll.showsHorizontalScrollIndicator = NO;
//        _scroll.bounces = NO;
//        [self.view addSubview:_scroll];
//        [_scroll mas_makeConstraints:^(MASConstraintMaker *make){
//            UIView *lastView = nil;
//            for (int i = 0; i < self.photos.count; i++)
//            {
//                UIImageView *iv = [UIImageView new];
//                iv.contentMode = UIViewContentModeScaleAspectFit;
//                iv.image = [UIImage imageNamed:self.photos[i]];
//                [_scroll addSubview:iv];
//                [iv mas_makeConstraints:^(MASConstraintMaker *make) {
//                    make.size.mas_equalTo(_scroll);
//                    make.top.bottom.mas_equalTo(0);
//                    if(i == 0)
//                    {
//                        make.leftMargin.mas_equalTo(0);
//                    }
//                    else
//                    {
//                        make.left.mas_equalTo(lastView.mas_right).mas_equalTo(0);
//                        if(i == self.photos.count - 1)
//                        {
//                            make.right.mas_equalTo(0);
//                        }
//                    }
//                }];
//                lastView = iv;
//            }
//        }];
    }
    return _scroll;
}

- (NSArray *)photos {
    if(_photos == nil) {
        _photos = @[@"edition1.jpg",@"edition2.jpg",@"edition3.jpg",@"edition4.jpg"];
    }
    return _photos;
}
- (void)viewDidLoad {
    [super viewDidLoad];
   // self.scroll.hidden = NO;
    [self setUpScrollView];
    self.scroll.delegate = self;
}
//最后一个页面  点击任何一个地方 进入主界面    storyboard中进入的........
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self performSegueWithIdentifier:@"toMainTabBarLine" sender:nil];
}


/**
 *  设置 scroll  frame 排版
 */
-(void)setUpScrollView
{

    UIScrollView *scv = [[UIScrollView alloc] init];
    self.scroll = scv;
    
    scv.pagingEnabled = YES;
    scv.showsHorizontalScrollIndicator = NO;
    scv.bounces = NO;
    scv.frame = self.view.bounds;
    scv.contentSize = CGSizeMake(scv.bounds.size.width * NUMBEROFPHOTO, scv.bounds.size.height);
    
    for(NSInteger i = 0; i < NUMBEROFPHOTO; i++)
    {
        NSString *str = [NSString stringWithFormat:@"edition%ld.jpg",i+1];
        UIImageView *imageView = [[UIImageView alloc] init];
        //imageView.contentMode = UIViewContentModeScaleAspectFit;
        imageView.frame = CGRectMake( SCREENWIDTH * i , ZERO, scv.bounds.size.width, scv.bounds.size.height);
        imageView.image = [UIImage imageNamed:str];
        [scv addSubview:imageView];
        if(i == 3)
        {
            [self setEnterBtn:imageView];
        }
    }
    [self.view addSubview:scv];
    
}
/**
 *  设置进入主界面按钮  这里不使用   而是点击屏幕任意地方进入
 *
 *  @param imageView 传入的最后一张图片
 */
-(void)setEnterBtn:(UIImageView *)imageView
{
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(210, 410, 80, 40);
    //btn.backgroundColor = [UIColor redColor];
    //btn.titleLabel.text = @"123";
    [btn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    [imageView addSubview:btn];
    imageView.userInteractionEnabled = YES;

}
-(void)btnClick:(UIButton *)btn
{
    //FirstTableViewController *ftc = [[FirstTableViewController alloc] init];
    // UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:ftc];
    [self performSegueWithIdentifier:@"toMainTabBarLine" sender:nil];
    
    //    [self presentViewController:nav animated:YES completion:^{
    //
    //        [self ChangeRoot:ftc];
    //
    //    }];
    
}
//切换根视图  资源不浪费
-(void)ChangeRoot:(UIViewController *)ftc
{
    UIApplication *application = [UIApplication sharedApplication];
    UIWindow *window = application.keyWindow;
    window.rootViewController = ftc;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UIScrollViewDelegate
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (scrollView.contentOffset.x / scrollView.bounds.size.width == 3)
    {
        self.scroll.userInteractionEnabled = NO;
    }
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/



@end
