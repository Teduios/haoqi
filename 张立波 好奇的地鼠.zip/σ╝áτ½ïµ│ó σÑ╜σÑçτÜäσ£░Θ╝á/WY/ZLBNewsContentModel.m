//
//  NewsContentModel.m
//  WY
//
//  Created by tarena on 15/12/13.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "ZLBNewsContentModel.h"
#import "ZLBNewsImageModel.h"
@implementation ZLBNewsContentModel

+(instancetype)pareseJsonByDic:(NSDictionary *)dic{
    return [[self alloc] initWithJsonDic:dic];
}
-(instancetype)initWithJsonDic:(NSDictionary *)dic{
    if(self = [super init]){
        self.title = dic[@"title"];
        self.ptime = dic[@"ptime"];
        self.body = dic[@"body"];
        
         NSArray *imgArray = dic[@"img"];
        NSMutableArray *temArray = [NSMutableArray arrayWithCapacity:imgArray.count];
        for (NSDictionary *dict in imgArray) {
            ZLBNewsImageModel *imgModel = [ZLBNewsImageModel detailImgWithDict:dict];
            [temArray addObject:imgModel];
        }
        self.img = temArray;
        
        
    }
    return self;
}
@end
