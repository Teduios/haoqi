//
//  ImagesViewController.h
//  WY
//
//  Created by tarena on 15/12/7.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZLBNewsNormalCell.h"
#import "ZLBNewsImage.h"

@interface ZLBImagesViewController : UIViewController

/**
 *  接收传进来的新闻
 */
@property(nonatomic,strong)NewsNromal *news;



@end
