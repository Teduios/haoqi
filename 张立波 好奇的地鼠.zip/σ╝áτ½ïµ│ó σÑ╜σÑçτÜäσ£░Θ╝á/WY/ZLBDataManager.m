//
//  ZLBDataManager.m
//  WY
//
//  Created by tarena on 15/12/20.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "ZLBDataManager.h"
#import "ZLBRadioModel.h"
#import "ZLBNetWorkTools.h"
@implementation ZLBDataManager

+(NSArray *)getAndParseRadioList:(NSDictionary *)radioList{
    NSMutableArray *mutableArr = [NSMutableArray array];

    NSArray *cList = radioList[@"cList"];
    for (NSDictionary *v in cList) {
     
        NSString *temp = v[@"cname"];
        NSArray *tList = v[@"tList"];
        for (NSDictionary *v2 in tList) {
            ZLBRadioModel *model = [ZLBRadioModel new];
            model.name = temp;
            model.docid = model.imgsrc = v2[@"radio"][@"docid"];
            model.tname = v2[@"tname"];
            model.imgsrc = v2[@"radio"][@"imgsrc"];
            //http://c.m.163.com//nc/article/BB28DB7300964KM4/full.html
            model.url = [NSString stringWithFormat:@"/nc/article/%@/full.html",v2[@"radio"][@"docid"]];
            [mutableArr addObject:model];
        }
        
    }
    return [mutableArr copy];
  
   
    
}
@end
