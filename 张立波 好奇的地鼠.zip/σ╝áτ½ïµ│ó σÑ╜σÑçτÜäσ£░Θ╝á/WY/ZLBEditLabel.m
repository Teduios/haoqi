//
//  editLabel.m
//  WY
//
//  Created by tarena on 15/11/21.
//  Copyright (c) 2015年 tarena. All rights reserved.
//

#import "ZLBEditLabel.h"

@implementation ZLBEditLabel

-(instancetype)initWithFrame:(CGRect)frame{
    if(self = [super initWithFrame:frame]){
        self.textAlignment = NSTextAlignmentCenter;
        self.font = [UIFont italicSystemFontOfSize:18];
        self.scale = 0.0;
    }
    return self;
}
//通过改变scale 的值改变其他属性
-(void)setScale:(CGFloat)scale{
    self.textColor = [UIColor colorWithRed:scale green:0 blue:0 alpha:1];
    CGFloat min = 0.7;
    CGFloat realScale = min + (1 - min) *scale;
    self.transform = CGAffineTransformMakeScale(realScale, realScale);
}

@end
