//
//  newsTableViewController.m
//  WY
//
//  Created by tarena on 15/11/21.
//  Copyright (c) 2015年 tarena. All rights reserved.
//
#define PHOTOSCROLLHEIGHT (self.view.bounds.size.height * 0.3)
#define WIDTH  (self.view.bounds.size.width)
#define HEIGHT (self.view.bounds.size.height)
#import "ZLBNewsTableViewController.h"
#import "ZLBNewsContentViewController.h"
#import "ZLBImagesViewController.h"
#import "NewsNromal.h"
#import "UIImageView+WebCache.h"
#import "UIImageView+AnotherTag.h"
#import "MJRefresh.h"
#import "NewsNromal.h"
#import "ZLBNewsImagesCell.h"
#import "ZLBNewsNormalCell.h"

#import "MJChiBaoZiHeader.h"
#import "MJChiBaoZiFooter.h"
#import "MJChiBaoZiFooter2.h"
#import "MJDIYHeader.h"
#import "MJDIYAutoFooter.h"
#import "MJDIYBackFooter.h"
@interface ZLBNewsTableViewController () <UIScrollViewDelegate>
/**
 *  广告图片
 */
@property(nonatomic,strong) NSMutableArray *adPhotos;
/**
 *  ad的 size
 */
@property(nonatomic) CGSize  adsize;

/**
 *  导航图片
 */
@property(nonatomic,strong) UIScrollView *photoScroll;
///**
// *  数据交给这个类处理
// */
//@property(nonatomic,strong) NewsHandleData *newsHandleData;
/**
 *  新闻类存储在这个数组中
 */
@property(nonatomic,strong)NSMutableArray *arrayList;
@end


@implementation ZLBNewsTableViewController
-(NSMutableArray *)arrayList{
    if(!_arrayList){
        _arrayList = [NSMutableArray array];
    }
    return _arrayList;
}

-(NSMutableArray *)adPhotos{
    if(!_adPhotos){
        _adPhotos = [NSMutableArray array];
    }
    return _adPhotos;
}

-(CGSize)adsize{
    return _adsize;
}
- (void)viewDidLoad {
      [super viewDidLoad];
    
    //self.automaticallyAdjustsScrollViewInsets = NO;
    self.adsize = CGSizeMake(WIDTH, PHOTOSCROLLHEIGHT);
    self.tableView.mj_header = [MJChiBaoZiHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadData)];
    self.tableView.mj_footer = [MJChiBaoZiFooter footerWithRefreshingTarget:self refreshingAction:@selector(loadMoreData)];
    [self.tableView.mj_header beginRefreshing];
//    [self.tableView addHeaderWithTarget:self action:@selector(loadData)];
//    [self.tableView addFooterWithTarget:self action:@selector(loadMoreData)];
//    [self.tableView headerBeginRefreshing];
    
}
-(void)viewWillAppear:(BOOL)animated{
    
}
////接收通知
//-(void)kDataChangeOver{
//    [self.tableView reloadData];
//}

-(void)addPhotoScroll{
    //创建scrollview
    UIScrollView *sv = [[UIScrollView alloc] init];
    self.photoScroll = sv;
    self.photoScroll.delegate = self;
    sv.tag = 1;
    sv.pagingEnabled = YES;
    sv.showsHorizontalScrollIndicator = NO;
    sv.bounces = NO;
    sv.frame = CGRectMake(0, 0, WIDTH, PHOTOSCROLLHEIGHT);
    sv.contentSize = CGSizeMake(WIDTH * self.adPhotos.count, PHOTOSCROLLHEIGHT);
    NSInteger t = self.tableView.bounds.size.width * (self.adPhotos.count / 2);
    sv.contentOffset = CGPointMake(t, 0);
    for (NSInteger i = 0; i < self.adPhotos.count; i++){
        UIImageView * imageView = [[UIImageView alloc] initWithFrame:CGRectMake(i * sv.bounds.size.width, 0, sv.bounds.size.width, sv.bounds.size.height)];
//为 prepare 中传值准备一个值 系统类的扩展
        //imageView -> tagOfImage = 100 + i;
        imageView.tagOfImage = @(100 + i);
        imageView.tag = i + 100;
        [imageView sd_setImageWithURL:[NSURL URLWithString:self.adPhotos[i]] placeholderImage:[UIImage imageNamed:@"placeholder"]];
//imageView.image = [UIImage imageNamed:self.adPhotos[i]];
        [sv addSubview:imageView];
//添加手势,,跳到    imagesViewController
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap:)];
        [imageView addGestureRecognizer:tap];
        imageView.userInteractionEnabled = YES;
    }
    NSInteger originOffset = self.tableView.bounds.size.width * (self.adPhotos.count / 2);
    sv.contentOffset = CGPointMake(originOffset, 0);
    self.tableView.tableHeaderView = sv;
}
#pragma mark - 点击最上方的照片
//点击照片手势
-(void)tap:(UITapGestureRecognizer*)tap{
    ZLBImagesViewController *ivc = [[UIStoryboard storyboardWithName:@"News" bundle:[NSBundle mainBundle]]instantiateViewControllerWithIdentifier:@"ImagesView"];
    ZLBNewsContentViewController *cvc = [[UIStoryboard storyboardWithName:@"News" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"ContentView"];
    UIImageView *iv = (UIImageView *)tap.view;
//    取得图片的标号 :第几张图片 最原先
    NSNumber *number = (NSNumber*)iv.tagOfImage;;
    NSInteger tagofImg = [number integerValue] - 100;
   
    NewsNromal *news = self.arrayList[0];
//    如果有照片集 就进图片没有就进新闻
    if(news.photosetID){
        if(tagofImg != 0){
            NSString *imgsrc;
            if(news.ads.count == 1){
                if (tagofImg == 3) {
                    tagofImg = 1;
                }else if (tagofImg == 2) {
                    tagofImg = 1;
                }
                imgsrc = news.ads[tagofImg - 1][@"url"];
            }
            else{
                imgsrc = news.ads[tagofImg - 1][@"url"];
            }
            
            news.photosetID = imgsrc;
        }
        ivc.news = news;
        [self.navigationController pushViewController:ivc animated:YES];
        
    }else{
        cvc.news =  news;
        [self.navigationController pushViewController:cvc animated:YES];
    }
}

#pragma mark - UIScrollViewDelegate 实现图片循环滚动
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    if(scrollView.tag == 1){
        //获得里面所有的imageView
        //虽然只有四张图片,, 但是 arr里面有五个对象,第五个 tag 为0
        NSArray *arr = scrollView.subviews;
        
        //scroll 的显示一直是这个偏移量,显示中间的那副图片
        NSInteger originOffset = self.tableView.bounds.size.width * (self.adPhotos.count / 2);
        if(scrollView.contentOffset.x - originOffset >= self.adsize.width  )
        {//手指往左滑动
            for (NSInteger index = 0; index < arr.count; index++)
            {
                    //四张图片 ,,,但要遍历其中五个内容
                    //这个循环内 计算的是前4个视图 ,,所以要用 insetSubView 不然第五个会造成错误
                    UIImageView *imageView = (UIImageView *)arr[index];
                
                    if ( 100 == imageView.tag) //第一张移到最后
                    {
                        CGPoint point = CGPointZero;
                        point.x = (self.adPhotos.count - 1) * self.adsize.width;
                        point.y = 0;
                        imageView.frame = CGRectMake(point.x, point.y, imageView.bounds.size.width, imageView.bounds.size.height);
                        imageView.tag = (self.adPhotos.count-1) + 100;
                        //把第一张视图    移动到scrollView 的最后第二个视图   因为最后一个视图不知道是什么,而且计算的是前四个视图    tag 为0的
                        //self.adPhotos.count -1 写成3也一样  但是前提是4张图片
                        [scrollView insertSubview:imageView atIndex:self.adPhotos.count -1 ];
                    }
                    else if(100 + index == imageView.tag)
                    {//以此往前移动一个
                        CGPoint point = CGPointZero;
                        point.x = (index- 1) * self.adsize.width;
                        point.y = 0;
                        imageView.frame = CGRectMake(point.x, point.y, imageView.bounds.size.width, imageView.bounds.size.height);
                        imageView.tag = 100 + index - 1;
                    }

                
            }
            scrollView.contentOffset = CGPointMake(originOffset, 0);
        }
        if(originOffset - scrollView.contentOffset.x  >=  self.adsize.width  ){
            //手指往右滑动
            //参照上面的  有些值反一下就好
            for (NSInteger index = arr.count - 1; index >= 0 ; index--){
                UIImageView *imageView = (UIImageView *)arr[index];
                if ( 100 + self.adPhotos.count - 1 == imageView.tag){//最后一张移到第一
                    CGPoint point = CGPointZero;
                    point.x = 0;
                    point.y = 0;
                    imageView.frame = CGRectMake(point.x, point.y, imageView.bounds.size.width, imageView.bounds.size.height);
                    imageView.tag = 100;
                    [scrollView insertSubview:imageView atIndex:0];
                }
                else if(100 + index == imageView.tag){//往后移动一个
                    CGPoint point = CGPointZero;
                    point.x = (index + 1) * self.adsize.width;
                    point.y = 0;
                    imageView.frame = CGRectMake(point.x, point.y, imageView.bounds.size.width, imageView.bounds.size.height);
                    imageView.tag = 100 + index + 1;
                }
            }
            scrollView.contentOffset = CGPointMake(originOffset, 0);
            
        }
    }
    
    
}
#pragma mark - 设置 cell 的高度
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    NewsNromal *newsNormal = self.arrayList[indexPath.row + 1];
    if (newsNormal.photosetID != nil) {
        return 120;
    } else {
        return  100;
    }
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}
#pragma mark - 传值
//storyboard 正向传值
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    //获取点击的 index
    NSInteger x = self.tableView.indexPathForSelectedRow.row;
//    获得目标控制器
    ZLBNewsContentViewController *ncvc = segue.destinationViewController;
//在这里传递点击的值的下标,,,,这里先设置为0
    NewsNromal *news = self.arrayList[x+1];
    ncvc.news = news;
}

#pragma mark - 刷新数据 上拉刷新
-(void)loadData{
   // [self.refreshControl beginRefreshing];
    // http://c.m.163.com//nc/article/headline/T1348647853363/0-30.html
    //T1348647853363就是 self.urlString  ,上一个界面通过获取 plist 文件的内容传进来的
    NSString *allUrlstring = [NSString stringWithFormat:@"/nc/article/%@/0-20.html",self.urlString];
    [self loadDataForType:1 withURL:allUrlstring];
}

#pragma mark - 刷新数据 下拉加载
-(void)loadMoreData{
    NSString *allUrlString = [NSString stringWithFormat:@"/nc/article/%@/%ld-20.html",self.urlString,((NSInteger)self.arrayList.count - (int)self.arrayList.count % 10)];
    [self loadDataForType:2 withURL:allUrlString];
    
}
// ------公共方法
- (void)loadDataForType:(int)type withURL:(NSString *)allUrlstring{
    [[[ZLBNetWorkTools defaultNetWorkTools]GET:allUrlstring parameters:nil success:^(NSURLSessionDataTask *task, NSDictionary* responseObject) {
        //NSLog(@"%@",allUrlstring);
        NSString *key = [responseObject.keyEnumerator nextObject];
        NSArray *temArray = responseObject[key];
        NSMutableArray *arrayM = [NewsNromal objectArrayWithKeyValuesArray:temArray];
        //给 newsTableView 的数据源赋值
        if (type == 1) {
            self.arrayList = arrayM;
           //获得头部的滚动新闻
            NewsNromal *news = (NewsNromal*)arrayM[0];
          //添加 scroll 上
            self.adPhotos = nil;
            [self.adPhotos addObject:news.imageSrc];
            if(news.ads.count != 0){
                //特殊情况
                if(news.ads.count == 1){
                    [self.adPhotos addObject:news.ads.firstObject[@"imgsrc"]];
                    [self.adPhotos addObject:news.imageSrc];
                    [self.adPhotos addObject:news.ads.firstObject[@"imgsrc"]];
                }else{
                    for (NSDictionary *str in news.ads) {
                        [self.adPhotos addObject:str[@"imgsrc"]];
                    }
                }
            }
            [self addPhotoScroll];
            [self.tableView.mj_header endRefreshing];
            //[self.tableView headerEndRefreshing];
            [self.tableView reloadData];
        }else if(type == 2){
            [self.arrayList addObjectsFromArray:arrayM];
            [self.tableView.mj_footer endRefreshing];
//            [self.tableView footerEndRefreshing];
            [self.tableView reloadData];

        }
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        NSLog(@"%@",error);
    }] resume];
}

#pragma mark - TableView 数据处理
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
    
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
     return self.arrayList.count - 1;
    
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    //判断是不是 newsNromal 类
    //    +1 的原因是因为 有个表头视图  不算在这里
    
    if([self.arrayList[indexPath.row + 1] isKindOfClass:[NewsNromal class]]){
        NewsNromal *newsNormal = self.arrayList[indexPath.row + 1];
        if (newsNormal.photosetID != nil) {
            ZLBNewsImagesCell *cell2 = [tableView dequeueReusableCellWithIdentifier:@"NewsImagesCell"];
            cell2.newsImage = newsNormal;
            return cell2;
        } else {
            ZLBNewsNormalCell *cell = [tableView dequeueReusableCellWithIdentifier:@"NewsNormalCell"];
            cell.newsNormal = newsNormal;
            return  cell;
        }
    }
    return nil;
}
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{
    if ([cell respondsToSelector:@selector(setSeparatorInset:)])
    {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    if ([cell respondsToSelector:@selector(setLayoutMargins:)])
    {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
    
}
-(void)viewDidLayoutSubviews{
    if ([self.tableView respondsToSelector:@selector(setSeparatorInset:)]) {
        [self.tableView setSeparatorInset:UIEdgeInsetsMake(0,0,0,0)];
    }
    
    if ([self.tableView respondsToSelector:@selector(setLayoutMargins:)]) {
        [self.tableView setLayoutMargins:UIEdgeInsetsMake(0,0,0,0)];
    }
}


@end
