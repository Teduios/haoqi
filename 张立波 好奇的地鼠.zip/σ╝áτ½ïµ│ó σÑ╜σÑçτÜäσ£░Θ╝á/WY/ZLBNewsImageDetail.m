//
//  NewsImageDetail.m
//  WY
//
//  Created by tarena on 15/12/13.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "ZLBNewsImageDetail.h"

@implementation ZLBNewsImageDetail


+(instancetype)parseJsonByDic:(NSDictionary *)dic{
    return [[self alloc]initWithJsonDic:(dic)];
}
-(instancetype)initWithJsonDic:(NSDictionary *)dic{
    if(self = [super init]){
        self.note = dic[@"note"];
        self.imgurl = dic[@"imgurl"];
    }
    return self;
    
}
@end
