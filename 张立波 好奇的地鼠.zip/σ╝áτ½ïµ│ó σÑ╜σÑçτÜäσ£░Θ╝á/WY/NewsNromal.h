//
//  NewsNromal.h
//  WY
//
//  Created by tarena on 15/11/29.
//  Copyright © 2015年 tarena. All rights reserved.
//
/**
 "url_3w": "http://help.3g.163.com/15/1213/08/BAN18GSJ00963VRO.html",
 "votecount": 314,
 "replyCount": 933,
 "digest": "要在思想上政治上行动上自觉同党中央保持高度一致。",
 "url": "http://3g.163.com/ntes/15/1213/08/BAN18GSJ00963VRO.html",
 "docid": "BAN18GSJ00963VRO",
 "title": "习近平首次系统解读党校姓党",
 "source": "学习小组$",
 "priority": 240,
 "lmodify": "2015-12-13 08:49:02",
 "imgsrc": "http://img5.cache.netease.com/3g/2015/12/13/2015121308472962fbf.jpg",
 "subtitle": "",
 "boardid": "3g_bbs",
 "ptime": "2015-12-13 08:47:00"
 */
#import <Foundation/Foundation.h>

@interface NewsNromal : NSObject
/**
 *  标题
 */
@property(nonatomic,strong)NSString *title;
/**
 *  digest 副标题
 */
@property(nonatomic,strong)NSString *subtile;
/**
 *  网址
 */
@property(nonatomic,strong)NSString *url_3w;
/**
 *  3g 网址
 */
@property(nonatomic,strong)NSString *url;
/**
 *  评论数
 */
@property(nonatomic,strong)NSNumber *replyCount;
/**
 *  左边的小图....
 */
@property(nonatomic,strong)NSString *imageSrc;
/**
 *  其他图片
 */
@property(nonatomic,strong)NSArray *imgextra;
/**
 *  新闻 id
 */
@property (nonatomic,strong)NSString *docid;

/**
 *  photosetID
 */
@property (nonatomic,strong)NSString *photosetID;

@property(nonatomic)BOOL hasHead;

/**
 *  同义名
 */
@property (nonatomic,strong) NSString *alias;
/**
 *  有图片
 */
@property (nonatomic) BOOL hasImg;
/**
 *  图片地址
 */
@property(nonatomic,strong) NSString *imgsrc;
/**
 *  其他图片 暂时不明确什么用途
 */
@property(nonatomic,strong) NSArray *imagextra;
/**
 *  其他图片
 */
@property(nonatomic,strong) NSArray *ads;

+(NSArray *)demoData;
//将网络上的数组 装换成模型数组
+(NSMutableArray *)objectArrayWithKeyValuesArray:(NSArray *)array;
@end
