//
//  newsNormalCell.h
//  WY
//
//  Created by tarena on 15/11/29.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NewsNromal.h"
@interface ZLBNewsNormalCell : UITableViewCell

@property(nonatomic,strong)NewsNromal *newsNormal;

@end
