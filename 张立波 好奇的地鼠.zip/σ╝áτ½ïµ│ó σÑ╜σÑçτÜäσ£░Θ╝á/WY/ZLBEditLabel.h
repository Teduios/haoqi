//
//  editLabel.h
//  WY
//
//  Created by tarena on 15/11/21.
//  Copyright (c) 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZLBEditLabel : UILabel

@property(nonatomic,assign)CGFloat scale;
@end
