//
//  NewsImagesCell.m
//  WY
//
//  Created by tarena on 15/12/4.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "ZLBNewsImagesCell.h"
#import "UIImageView+WebCache.h"
@interface ZLBNewsImagesCell ()

@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

@property (weak, nonatomic) IBOutlet UILabel *commentLabel;
@property (weak, nonatomic) IBOutlet UIImageView *imageView1;
@property (weak, nonatomic) IBOutlet UIImageView *imageView2;
@property (weak, nonatomic) IBOutlet UIImageView *imageView3;

@end

@implementation ZLBNewsImagesCell
-(void)setNewsImage:(NewsNromal *)newsImage
{
    _newsImage = newsImage;
    self.titleLabel.text = newsImage.title;
    self.commentLabel.text = [NSString stringWithFormat:@"%@",newsImage.replyCount];
    [self.imageView1 sd_setImageWithURL:[NSURL URLWithString:newsImage.imageSrc]placeholderImage:[UIImage imageNamed:@"placeholder"]];
    [self.imageView2 sd_setImageWithURL:[NSURL URLWithString:newsImage.imgextra.firstObject[@"imgsrc"]]placeholderImage:[UIImage imageNamed:@"placeholder"]];
    [self.imageView3 sd_setImageWithURL:[NSURL URLWithString:newsImage.imgextra.lastObject[@"imgsrc"]]placeholderImage:[UIImage imageNamed:@"placeholder"]];
    
    

}
- (void)awakeFromNib {
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

@end
