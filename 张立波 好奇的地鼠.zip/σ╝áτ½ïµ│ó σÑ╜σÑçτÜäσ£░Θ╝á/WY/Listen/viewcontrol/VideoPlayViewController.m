//
//  VideoPlayViewController.m
//  WY
//
//  Created by tarena on 15/12/20.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "VideoPlayViewController.h"
#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVKit.h>
@interface VideoPlayViewController ()

@property (nonatomic, strong) AVPlayerViewController *vc;
//是够第一次出现
@property (nonatomic ) BOOL flag;
@end

@implementation VideoPlayViewController

-(void)viewDidAppear:(BOOL)animated{
     [self popoverPresentationController];
}

- (AVPlayerViewController *)vc {
    if(_vc == nil) {
        _vc = [[AVPlayerViewController alloc] init];
    }
    return _vc;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.rightBarButtonItem.title = @"返回";
    [self playVideo];
   
}
-(void)playVideo{

    self.vc.player = [AVPlayer playerWithURL:[NSURL URLWithString:self.mp4UrlStr]];
    [self presentViewController:self.vc animated:YES completion:nil];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/



@end
