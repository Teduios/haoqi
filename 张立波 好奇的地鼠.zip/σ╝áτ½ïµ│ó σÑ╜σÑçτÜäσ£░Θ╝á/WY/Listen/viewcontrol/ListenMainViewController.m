//
//  ViewController.m
//  zuoye
//
//  Created by tarena on 15/11/23.
//  Copyright (c) 2015年 tarena. All rights reserved.
//

#import "ListenMainViewController.h"

#import "SecondTableViewController.h"
@interface ListenMainViewController ()<UIScrollViewDelegate>
@property(nonatomic,strong)UIButton*button1;
@property(nonatomic,strong)UIButton*button2;
@property(nonatomic,strong)UIScrollView*big;
@end

@implementation ListenMainViewController
-(instancetype)initWithCoder:(NSCoder *)aDecoder{
    if(self = [super initWithCoder:aDecoder]){
        self.automaticallyAdjustsScrollViewInsets = NO;
        self.title = @"视听";
        
        self.navigationController.tabBarItem.selectedImage = [UIImage imageNamed: @"tabbar_icon_media_highlight"];
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
//    self.navigationController.navigationBar.barStyle=UIBarStyleBlack;
//        UIView*view=[[UIView alloc] init];
//    self.navigationController.navigationBar.barTintColor=[UIColor redColor];
//    UIButton*button1=[[UIButton alloc] init];
//    button1.frame=CGRectMake(0, 0, 100, 30);
//    UIButton*button2=[[UIButton alloc] init];
//
//    button2.frame=CGRectMake(button1.bounds.size.width,  0,100, 30);
//    view.frame=CGRectMake(0, 0, 200, 30);
//    view.layer.borderWidth=1.5;
//    view.layer.cornerRadius=17;
//    view.layer.borderColor=[UIColor whiteColor].CGColor;
//    //button2.layer.borderWidth=2;
//    button2.layer.cornerRadius=17;
//    
//    [button2 addTarget:self action:@selector(clickbutton22:) forControlEvents:UIControlEventTouchUpInside];
//
//    [button2 setTitle:@"电台" forState:UIControlStateNormal];
//
//
//    self.button2=button2;
//   
//    [view addSubview:button2];
//    self.navigationItem.titleView=view;
    [self addbigscroll];
        
    
    
}
-(void)clickbutton11:(UIButton*)b
{
    [self.big setContentOffset:CGPointMake(0, 0) animated:YES];
    
}
-(void)clickbutton22:(UIButton*)b
{
    [self.big setContentOffset:CGPointMake([UIScreen mainScreen].bounds.size.width, 0) animated:YES];
}
-(void)clickbutton1:(UIButton*)b
{
    b.backgroundColor=[UIColor whiteColor];
    [b setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [self.button2 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    self.button2.backgroundColor=[UIColor redColor];
    //self.big.contentOffset=CGPointMake(self.big.bounds.size.width, 64);
}
-(void)clickbutton2:(UIButton*)b
{
    b.backgroundColor=[UIColor whiteColor];
    [b setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [self.button1 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.button1 setBackgroundColor:[UIColor redColor]];//=[UIColor redColor];
    //[self.big setContentOffset:CGPointMake([UIScreen mainScreen].bounds.size.width, 0) animated:YES];
}

-(void)addbigscroll
{
    
    UIScrollView*big=[[UIScrollView alloc] init];
    
    self.big=big;
    big.bounces=NO;
    big.pagingEnabled=YES;
    big.frame=CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height-64-49);
    big.contentSize=CGSizeMake(big.bounds.size.width, big.bounds.size.height);
    //big.backgroundColor=[UIColor yellowColor];
    [self.view addSubview:big];

   
    UIScrollView*little2=[UIScrollView new];
    little2.frame=CGRectMake(0, 0,big.bounds.size.width, big.bounds.size.height);
    SecondTableViewController *t2=[[UIStoryboard storyboardWithName:@"Listen" bundle:[NSBundle mainBundle]]  instantiateViewControllerWithIdentifier:@"radio"];
    t2.tableView.frame=CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height-64-44);
    [little2 addSubview:t2.view];
    [big addSubview:little2];
    [self addChildViewController:t2];
    big.delegate=self;
}


@end
