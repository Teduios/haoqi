//
//  VideoPlayViewController.h
//  WY
//
//  Created by tarena on 15/12/20.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VideoPlayViewController : UIViewController

@property (nonatomic, strong) NSString *mp4UrlStr;
@end
