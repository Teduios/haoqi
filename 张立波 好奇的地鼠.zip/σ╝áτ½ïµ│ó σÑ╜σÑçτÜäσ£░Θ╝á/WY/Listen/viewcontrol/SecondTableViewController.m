//
//  SecondTableViewController.m
//  WY
//
//  Created by tarena on 15/12/21.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "SecondTableViewController.h"

#import "MJRefresh.h"
#import "ZLBDataManager.h"

#import "RadioTableViewCell1.h"
#import "VideoPlayViewController.h"
#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVKit.h>

#import "MJChiBaoZiHeader.h"
#import "MJChiBaoZiFooter.h"
#import "MJChiBaoZiFooter2.h"
#import "MJDIYHeader.h"
#import "MJDIYAutoFooter.h"
#import "MJDIYBackFooter.h"
@interface SecondTableViewController ()

//取得的数据
@property (nonatomic, strong) NSArray *newsArrayList;
@property (nonatomic, strong) AVPlayerViewController *vc;
@end

@implementation SecondTableViewController
- (AVPlayerViewController *)vc {
    if(_vc == nil) {
        _vc = [[AVPlayerViewController alloc] init];
    }
    return _vc;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.tableView.mj_header = [MJChiBaoZiHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadData)];
    [self.tableView.mj_header beginRefreshing];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(getRadioData:) name:@"kRadioDataGET" object:nil];
  
}
-(void)getRadioData:(NSNotification*)not{
    ZLBRadioModel *model = not.userInfo[@"model"];
    self.vc.player = [AVPlayer playerWithURL:[NSURL URLWithString:model.url_mp4]];
    [self presentViewController:self.vc animated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return self.newsArrayList.count / 3;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSMutableArray *mutable = [NSMutableArray array];
    for (int i = (int)indexPath.section * 3; i <= indexPath.section * 3 + 2; i++) {
        [mutable addObject:self.newsArrayList[i]];
    }
    
    //在 storyboard 无须注册
    RadioTableViewCell1 *cell = [tableView dequeueReusableCellWithIdentifier:@"radioCell2"];
    [cell setCell:cell withEadioModel:[mutable copy]];
    return cell;
}
#pragma mark -分区头和分区尾高度
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView *view = [UIView new];
    view.backgroundColor = [UIColor lightGrayColor];
    view.frame = CGRectMake(0, 0, 1, 1);
    return  view;
}
-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    UIView *view = [UIView new];
    view.backgroundColor = [UIColor lightGrayColor];
    view.frame = CGRectMake(0, 0, 1, 1);
    return  view;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 1;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 1;
}
#pragma mark - 分区高度
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 150;
    
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath  animated:YES];
}


#pragma mark - 刷新数据 上拉刷新
-(void)loadData{
    //http://c.3g.163.com/nc/topicset/ios/radio/index.html
    NSString *allUrlstring = [NSString stringWithFormat:@"/nc/topicset/ios/radio/index.html"];
    [self loadDataForType:1 withURL:allUrlstring];
}



// ------公共方法
- (void)loadDataForType:(int)type withURL:(NSString *)allUrlstring{
    [[[ZLBNetWorkTools defaultNetWorkTools]GET:allUrlstring parameters:nil success:^(NSURLSessionDataTask *task, NSDictionary* responseObject) {
        //        网页上的 key
       
        NSArray *temArray = [ZLBDataManager getAndParseRadioList:responseObject];
        self.newsArrayList = temArray;
        [self.tableView reloadData];
        [self.tableView.mj_header endRefreshing];
       // [self.tableView headerEndRefreshing];
        
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        NSLog(@"%@",error);
    }] resume];
}


/*
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:<#@"reuseIdentifier"#> forIndexPath:indexPath];
    
    // Configure the cell...
    
    return cell;
}
*/

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
