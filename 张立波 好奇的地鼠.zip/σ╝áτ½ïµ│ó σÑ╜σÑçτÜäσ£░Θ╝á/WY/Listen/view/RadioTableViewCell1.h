//
//  RadioTableViewCell1.h
//  WY
//
//  Created by tarena on 15/12/21.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZLBRadioModel.h"
@interface RadioTableViewCell1 : UITableViewCell

@property (nonatomic, strong)NSArray *radioModels;
-(void)setCell:(RadioTableViewCell1 *) cell withEadioModel:(NSArray *)radioModels;
@end
