//
//  RadioTableViewCell1.m
//  WY
//
//  Created by tarena on 15/12/21.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "RadioTableViewCell1.h"
#import "UIImageView+WebCache.h"

@interface RadioTableViewCell1 ()

@property (weak, nonatomic) IBOutlet UIImageView *imageView1;
@property (weak, nonatomic) IBOutlet UIImageView *imageView2;
@property (weak, nonatomic) IBOutlet UIImageView *imageView3;

@property (weak, nonatomic) IBOutlet UILabel *label1;
@property (weak, nonatomic) IBOutlet UILabel *label2;
@property (weak, nonatomic) IBOutlet UILabel *label3;
@property (nonatomic, strong)ZLBRadioModel *model1;
@property (nonatomic, strong)ZLBRadioModel *model2;
@property (nonatomic, strong)ZLBRadioModel *model3;
@end
@implementation RadioTableViewCell1
-(void)setCell:(RadioTableViewCell1 *) cell withEadioModel:(NSArray *)radioModels{
    ZLBRadioModel *model1 = radioModels[0];
    self.model1 = model1;
    ZLBRadioModel *model2 = radioModels[1];
    self.model2 = model2;
    ZLBRadioModel *model3 = radioModels[2];
    self.model3 = model3;
    [cell.imageView1 sd_setImageWithURL:[NSURL URLWithString:model1.imgsrc] placeholderImage:[UIImage imageNamed:@"placeholder"]];
    [cell.imageView2 sd_setImageWithURL:[NSURL URLWithString:model2.imgsrc] placeholderImage:[UIImage imageNamed:@"placeholder"]];
    [cell.imageView3 sd_setImageWithURL:[NSURL URLWithString:model3.imgsrc] placeholderImage:[UIImage imageNamed:@"placeholder"]];
    cell.label1.text = model1.tname;
    cell.label2.text = model2.tname;
    cell.label3.text = model3.tname;
    
}
//http://c.m.163.com//nc/article/BB28DB7300964KM4/full.html
-(void)parse:(ZLBRadioModel*)model{
    [[[ZLBNetWorkTools defaultNetWorkTools]GET:model.url parameters:nil success:^(NSURLSessionDataTask *task, NSDictionary* responseObject) {
        //        网页上的 key
        model.url_mp4 = responseObject[model.docid][@"video"][0][@"url_mp4"];
        NSLog(@"1");
      
        //发送通知
        [[NSNotificationCenter defaultCenter]postNotificationName:@"kRadioDataGET" object:self userInfo:@{@"model":model}];
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        NSLog(@"%@",error);
    }] resume];
}
- (IBAction)button1Clcik:(id)sender {
    [self parse:self.model1];
}
- (IBAction)button2Click:(id)sender {
    [self parse:self.model2];
}
- (IBAction)button3Click:(id)sender {
    [self parse:self.model3];
}



- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
