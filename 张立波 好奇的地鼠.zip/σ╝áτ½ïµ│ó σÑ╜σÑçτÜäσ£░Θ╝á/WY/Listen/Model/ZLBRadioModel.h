//
//  ZLBRadioModel.h
//  WY
//
//  Created by tarena on 15/12/21.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZLBRadioModel : NSObject
//name
@property (nonatomic, strong) NSString *name;
//tname
@property (nonatomic, strong) NSString *tname;
//图片
@property (nonatomic, strong) NSString *imgsrc;
//url
@property (nonatomic, strong) NSString *url;
//docid 得到语音
@property (nonatomic, strong) NSString *docid;

@property (nonatomic, strong) NSString *url_mp4;
//http://c.3g.163.com/nc/article/BB28DB7300964KM4/full.html
@end
