//
//  ZLBNetWorkTools.h
//  WY
//
//  Created by tarena on 15/12/10.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "AFHTTPSessionManager.h"

@interface ZLBNetWorkTools : AFHTTPSessionManager

+(instancetype)defaultNetWorkTools;
+(instancetype)defaultNetWorkToolsWithoutBaseUrl;
@end
