//
//  ZLBTabBarController.m
//  WY
//
//  Created by tarena on 15/11/24.
//  Copyright (c) 2015年 tarena. All rights reserved.
//

#import "ZLBTabBarController.h"

@interface ZLBTabBarController ()

@end

@implementation ZLBTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
 
    for (UIViewController *vc in self.viewControllers){
        UITabBarItem *barItem = vc.tabBarItem;
//      UIImage*image  = [UIImage imageNamed:@"QingTian"];
        UIImage *selectedImage = [vc.tabBarItem.selectedImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        barItem.selectedImage = selectedImage;
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        attributes[NSForegroundColorAttributeName] = [UIColor redColor];
        [barItem setTitleTextAttributes:attributes forState:UIControlStateSelected];
        [barItem setTitlePositionAdjustment:UIOffsetMake(0, -2)];
        
    }
//     UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.tabBar.bounds.size.width, self.tabBar.bounds.size.height)];
//    view.backgroundColor = [UIColor whiteColor];
//   [self.tabBar insertSubview:view atIndex:0];
}







- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}



@end
