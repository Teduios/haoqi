//
//  ZLBDataManager.h
//  WY
//
//  Created by tarena on 15/12/20.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZLBDataManager : NSObject
//返回Listen的数据
+(NSArray*)getAndParseVideoList:(NSArray *)videoList;

+(NSArray *)getAndParseRadioList:(NSDictionary *)radioList;
@end
