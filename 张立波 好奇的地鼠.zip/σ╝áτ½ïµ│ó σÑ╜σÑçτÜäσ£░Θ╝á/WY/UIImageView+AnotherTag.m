//
//  UIImageView+AnotherTag.m
//  WY
//
//  Created by tarena on 15/12/15.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "UIImageView+AnotherTag.h"

@implementation UIImageView (AnotherTag)

-(NSObject *)tagOfImage{
    return objc_getAssociatedObject(self, @selector(tagOfImage));
}
-(void)setTagOfImage:(NSObject *)tagOfImage{
   objc_setAssociatedObject(self, @selector(tagOfImage), tagOfImage, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}
@end
