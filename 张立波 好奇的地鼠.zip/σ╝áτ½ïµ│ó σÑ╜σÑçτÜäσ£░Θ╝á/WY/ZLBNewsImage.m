//
//  NewsImage.m
//  WY
//
//  Created by tarena on 15/12/13.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "ZLBNewsImage.h"
#import "ZLBNewsImageDetail.h"
@implementation ZLBNewsImage

+(instancetype)parseJsonByDic:(NSDictionary *)dic{
    return [[self alloc]initWithJsonDic:(NSDictionary *)dic];
}
-(instancetype)initWithJsonDic:(NSDictionary *)dic{
    if(self = [super init]){
        
        self.desc = dic[@"desc"];
        NSArray *temparr = dic[@"photos"];
//解析 不会解释
        NSMutableArray *temp = [NSMutableArray array];
        for (NSDictionary *dic in temparr) {
            ZLBNewsImageDetail *detail = [ZLBNewsImageDetail parseJsonByDic:dic];
            [temp addObject:detail];
        }
        self.photos = [temp copy];
        
    }
    return self;
    
}
@end
