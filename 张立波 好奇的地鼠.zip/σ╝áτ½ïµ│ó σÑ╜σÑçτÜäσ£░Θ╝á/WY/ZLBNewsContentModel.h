//
//  NewsContentModel.h
//  WY
//
//  Created by tarena on 15/12/13.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZLBNewsContentModel : NSObject
/**
 *  新闻标题
 */
@property (nonatomic , copy) NSString *title;
/**
 *  新闻发布时间
 */
@property (nonatomic , copy) NSString *ptime;
/**
 *  新闻内容
 */
@property (nonatomic, copy) NSString *body;
/**
 *  新闻配图
 */
@property(nonatomic,strong)NSArray *img;

+(instancetype)pareseJsonByDic:(NSDictionary*)dic;

@end
