//
//  UIImageView+AnotherTag.h
//  WY
//
//  Created by tarena on 15/12/15.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <objc/runtime.h>
@interface UIImageView (AnotherTag)

@property (nonatomic,strong)NSObject *tagOfImage;
@end
