//
//  NewsContentViewController.h
//  WY
//
//  Created by tarena on 15/12/4.
//  Copyright © 2015年 tarena. All rights reserved.
//

/**
 *  ViewController  用于显示新闻的内容
 属性:
  newsContent
 
 */
#import <UIKit/UIKit.h>
#import "NewsNromal.h"
@interface ZLBNewsContentViewController : UIViewController
/**
 *  接收传进来的新闻
 */
@property(nonatomic,strong)NewsNromal *news;


@end
