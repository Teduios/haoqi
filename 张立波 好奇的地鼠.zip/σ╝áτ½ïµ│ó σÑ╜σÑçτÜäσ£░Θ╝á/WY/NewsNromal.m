//
//  NewsNromal.m
//  WY
//
//  Created by tarena on 15/11/29.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "NewsNromal.h"
#import "ZLBNewsImage.h"
@implementation NewsNromal

+(NSArray*)demoData
{
    NewsNromal *n1 = [[NewsNromal alloc] init];
    n1.title = @"宁夏首虎在休会10分钟被带走";

    n1.subtile = @"中纪委副书记在银川开会,宁夏几乎全部领导均参加飒飒大师萨达.";
  

    
    NewsNromal *n2 = [[NewsNromal alloc] init];
    n2.title = @"宁夏首虎在休会10分钟被带走";
 
    n2.subtile = @"中纪委副书记在银川开会,宁夏几乎全部领导均参加飒飒大师萨达.";


    
    
    NewsNromal *n3 = [[NewsNromal alloc] init];
    n3.title = @"宁夏首虎在休会10分钟被带走";

    n3.subtile = @"中纪委副书记在银川开会,宁夏几乎全部领导均参加飒飒大师萨达.";
   

    
    
    NewsNromal *n4 = [[NewsNromal alloc] init];
    n4.title = @"宁夏首虎在休会10分钟被带走";
    n4.subtile = @"中纪委副书记在银川开会,宁夏几乎全部领导均参加飒飒大师萨达.";


    return @[n1,n2,n3,n4];
}

+(NSMutableArray *)objectArrayWithKeyValuesArray:(NSArray *)array
{
   // [news setValuesForKeysWithDictionary:array];
    NSMutableArray *n = [NSMutableArray array];
    for (NSDictionary *dic in array) {
//        if(dic[@"hasHead"]){
////            头部滚动图片
//            NewsTop *top = [[NewsTop alloc] init];
//            top.imgsrc = dic[@"imgsrc"];
//            top.title = dic[@"title"];
//            top.replyCount = dic[@"replyCount"];
//            //top.imagextra = dic[@"imgextra"];
//            top.ads = dic[@"ads"];
//            [n addObject:top];
//            
//        }else{
//            其他 cell
            NewsNromal *news = [[NewsNromal alloc] init];
            news.imageSrc = dic[@"imgsrc"];
            news.title = dic[@"title"];
            news.subtile = dic[@"digest"];
            news.replyCount = dic[@"replyCount"];
            news.url = dic[@"url"];
            news.url_3w = dic[@"url_3w"];
            news.imgextra = dic[@"imgextra"];
            news.docid = dic[@"docid"];
            news.photosetID = dic[@"photosetID"];
            news.ads = dic[@"ads"];
            [n addObject:news];
        
        
    }
    return n;

    
    
    
}

@end
