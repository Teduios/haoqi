//
//  WelcomeViewController.h
//  WY
//
//  Created by tarena on 15/11/19.
//  Copyright (c) 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
@interface ZLBWelcomeViewController : UIViewController

@end
