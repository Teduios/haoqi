//
//  newsTableViewController.h
//  WY
//
//  Created by tarena on 15/11/21.
//  Copyright (c) 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZLBNewsTableViewController : UITableViewController

/** 传递进来的 url*/
@property(nonatomic,strong) NSString *urlString;

@property(nonatomic) NSInteger index;
@end
